const express = require("express")

const User = require("../model/user.model")

const register = async(req,res)=>{
    try {
        let user = await User.findOne({email:req.body.email})

        if(user){
            return res.statuse(400).send({message:"Email already exist"})
        }
        user = await User.create(req.body)
        return res.status(200).send(user)
    } catch (error) {
        res.status(400).send({message:error.message})
    }
}

const login = async(req,res)=>{
    try {
        let user = await User.findOne({email:req.body.email})

        if(!user){
            return res.statuse(400).send({message:"Wrong email or password"})
        }
        const match = user.checkPassword(req.body.password)
        if(!match){
            return res.status(400).send({message:err.message})
        }
        return res.status(200).send(user)
        // user = await User.create(req.body)
        // return res.status(200).send(user)
    } catch (error) {
        res.status(400).send({message:error.message})
    }
}

module.exports={register,login}

