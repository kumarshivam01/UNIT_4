const mongoose = require("mongoose")

module.exports = ()=>{
    return mongoose.connect(
        "mongodb+srv://c4:c4@cluster0.7hquq.mongodb.net/user?retryWrites=true&w=majority"
    )
}