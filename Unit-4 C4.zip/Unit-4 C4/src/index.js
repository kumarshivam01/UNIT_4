const express = require("express")

const todoController = require("../src/controller/todo.controller")

const userController = require("./controller/user.controller")

const {register,login} = require("./controller/auth.controllers")

const app = express()

app.use("./users",userController)

app.post("/register",register)

app.post("/login",login)

app.use(express.json())

app.use("/todos",todoController)


module.exports=app