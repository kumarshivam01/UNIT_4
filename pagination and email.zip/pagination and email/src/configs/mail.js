const nodemailer = require("nodemailer");

module.exports = nodemailer.createTransport({
    host: "smtp.mailtrap.io",
    port: 587,
    secure: false, // true for 465, false for other ports
    auth: {
      user: "c468b1e6b51ed4", // generated ethereal user
      pass: "6bbc1ef773b587", // generated ethereal password
    },
  });