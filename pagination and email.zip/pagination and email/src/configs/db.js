const mongoose = require("mongoose")

module.exports=()=>{
    return mongoose.connect("mongodb+srv://pagination:pagination@cluster0.c5ipa.mongodb.net/pagination?retryWrites=true&w=majority")
}