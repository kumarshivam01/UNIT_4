
const express = require("express")



const productController = require("./controller/product.controller")

const app = express()

app.use(express.json())

app.use("/products", productController)

"use strict";


// async..await is not allowed in global scope, must use a wrapper
async function main() {

  // create reusable transporter object using the default SMTP transport
  

  // send mail with defined transport object
 

  
}

main().catch(console.error);

module.exports=app;


